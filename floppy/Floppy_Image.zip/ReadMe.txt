The Floppy Disk Image file "floppy.img" was created using dd and then formated using Windows 98 DOS.

In a Terminal (/Applications/Utilities/Terminal) copy and paste the following command to create an unformatted 1.44 MB Floppy Disk Image.

dd if=/dev/zero bs=512 count=2880 of=floppy.img

###
